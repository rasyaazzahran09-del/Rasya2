'use strict';

const http = require('node:http');
const crypto = require('node:crypto');
const { URL } = require('node:url');
const config = require('./config');

const state = {
  offset: 0,
  busyChats: new Set()
};

function assertConfig() {
  const required = [
    'TELEGRAM_BOT_TOKEN',
    'GITHUB_TOKEN',
    'GITHUB_OWNER',
    'GITHUB_REPO'
  ];

  const missing = required.filter((key) => !config[key]);
  if (missing.length) {
    throw new Error(`Missing environment variables: ${missing.join(', ')}`);
  }
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function randomId(prefix = 'job') {
  return `${prefix}-${Date.now()}-${crypto.randomBytes(4).toString('hex')}`;
}

function isAllowedChat(chatId) {
  if (!config.ALLOWED_CHAT_IDS.length) return true;
  return config.ALLOWED_CHAT_IDS.includes(String(chatId));
}

async function tg(method, payload = {}, isFormData = false) {
  const endpoint = `https://api.telegram.org/bot${config.TELEGRAM_BOT_TOKEN}/${method}`;
  const options = {
    method: 'POST'
  };

  if (isFormData) {
    options.body = payload;
  } else {
    options.headers = { 'content-type': 'application/json' };
    options.body = JSON.stringify(payload);
  }

  const res = await fetch(endpoint, options);
  const data = await res.json();
  if (!data.ok) {
    throw new Error(`Telegram API error (${method}): ${JSON.stringify(data)}`);
  }
  return data.result;
}

async function sendMessage(chatId, text, extra = {}) {
  return tg('sendMessage', {
    chat_id: chatId,
    text,
    parse_mode: 'Markdown',
    ...extra
  });
}

async function sendDocumentFromBuffer(chatId, buffer, filename, caption = '') {
  const form = new FormData();
  form.append('chat_id', String(chatId));
  if (caption) form.append('caption', caption);
  form.append('document', new Blob([buffer]), filename);
  return tg('sendDocument', form, true);
}

async function getTelegramFileBytes(fileId) {
  const file = await tg('getFile', { file_id: fileId });
  const fileUrl = `https://api.telegram.org/file/bot${config.TELEGRAM_BOT_TOKEN}/${file.file_path}`;
  const res = await fetch(fileUrl);
  if (!res.ok) throw new Error(`Failed downloading Telegram file: ${res.status}`);
  const arrayBuffer = await res.arrayBuffer();
  return Buffer.from(arrayBuffer);
}

function encodeGitHubPath(path) {
  return path.split('/').map(encodeURIComponent).join('/');
}

async function gh(path, { method = 'GET', body, headers = {} } = {}) {
  const url = `https://api.github.com${path}`;
  const res = await fetch(url, {
    method,
    headers: {
      Accept: 'application/vnd.github+json',
      Authorization: `Bearer ${config.GITHUB_TOKEN}`,
      'X-GitHub-Api-Version': '2022-11-28',
      'User-Agent': 'telegram-flutter-builder-bot',
      ...headers
    },
    body: body ? JSON.stringify(body) : undefined
  });

  if (res.status === 204) return null;

  const text = await res.text();
  let data;
  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    data = text;
  }

  if (!res.ok) {
    throw new Error(`GitHub API error ${res.status} ${method} ${path}: ${typeof data === 'string' ? data : JSON.stringify(data)}`);
  }

  return data;
}

async function ensureBranch(branch, sourceBranch) {
  try {
    await gh(`/repos/${config.GITHUB_OWNER}/${config.GITHUB_REPO}/git/ref/heads/${encodeURIComponent(branch)}`);
    return;
  } catch (error) {
    if (!String(error.message).includes('404')) throw error;
  }

  const base = await gh(`/repos/${config.GITHUB_OWNER}/${config.GITHUB_REPO}/git/ref/heads/${encodeURIComponent(sourceBranch)}`);
  await gh(`/repos/${config.GITHUB_OWNER}/${config.GITHUB_REPO}/git/refs`, {
    method: 'POST',
    body: {
      ref: `refs/heads/${branch}`,
      sha: base.object.sha
    }
  });
}

async function upsertRepoFile(path, contentBuffer, message, branch) {
  let sha;
  try {
    const existing = await gh(`/repos/${config.GITHUB_OWNER}/${config.GITHUB_REPO}/contents/${encodeGitHubPath(path)}?ref=${encodeURIComponent(branch)}`);
    sha = existing.sha;
  } catch (error) {
    if (!String(error.message).includes('404')) throw error;
  }

  return gh(`/repos/${config.GITHUB_OWNER}/${config.GITHUB_REPO}/contents/${encodeGitHubPath(path)}`, {
    method: 'PUT',
    body: {
      message,
      content: contentBuffer.toString('base64'),
      branch,
      sha
    }
  });
}

async function deleteRepoFile(path, message, branch) {
  try {
    const existing = await gh(`/repos/${config.GITHUB_OWNER}/${config.GITHUB_REPO}/contents/${encodeGitHubPath(path)}?ref=${encodeURIComponent(branch)}`);
    await gh(`/repos/${config.GITHUB_OWNER}/${config.GITHUB_REPO}/contents/${encodeGitHubPath(path)}`, {
      method: 'DELETE',
      body: {
        message,
        branch,
        sha: existing.sha
      }
    });
  } catch (error) {
    if (!String(error.message).includes('404')) throw error;
  }
}

async function triggerBuild(buildId, zipRepoPath) {
  return gh(`/repos/${config.GITHUB_OWNER}/${config.GITHUB_REPO}/actions/workflows/${encodeURIComponent(config.GITHUB_WORKFLOW_ID)}/dispatches`, {
    method: 'POST',
    body: {
      ref: config.GITHUB_BRANCH,
      inputs: {
        build_id: buildId,
        zip_path: zipRepoPath,
        output_branch: config.GITHUB_OUTPUT_BRANCH
      }
    }
  });
}

async function findWorkflowRunByBuildId(buildId) {
  const runs = await gh(`/repos/${config.GITHUB_OWNER}/${config.GITHUB_REPO}/actions/workflows/${encodeURIComponent(config.GITHUB_WORKFLOW_ID)}/runs?per_page=20`);
  return (runs.workflow_runs || []).find((run) => run.display_title === buildId || run.name === buildId || String(run.head_branch) === config.GITHUB_BRANCH);
}

async function waitForRun(buildId) {
  const start = Date.now();
  let runId = null;

  while (Date.now() - start < config.BUILD_TIMEOUT_MS) {
    const runs = await gh(`/repos/${config.GITHUB_OWNER}/${config.GITHUB_REPO}/actions/workflows/${encodeURIComponent(config.GITHUB_WORKFLOW_ID)}/runs?event=workflow_dispatch&per_page=30`);
    const matched = (runs.workflow_runs || []).find((run) => {
      const inputBuildId = run.display_title === buildId || run.name === buildId;
      const recentEnough = Date.now() - new Date(run.created_at).getTime() < 1000 * 60 * 10;
      return inputBuildId || recentEnough;
    });

    if (matched) {
      runId = matched.id;
      if (matched.status === 'completed') {
        return matched;
      }
    }

    await sleep(config.POLL_INTERVAL_MS);
  }

  throw new Error(`Build timeout. runId=${runId || 'unknown'}`);
}

async function waitForApk(buildId) {
  const start = Date.now();
  while (Date.now() - start < config.BUILD_TIMEOUT_MS) {
    try {
      const file = await gh(`/repos/${config.GITHUB_OWNER}/${config.GITHUB_REPO}/contents/builds/${encodeURIComponent(buildId)}.apk?ref=${encodeURIComponent(config.GITHUB_OUTPUT_BRANCH)}`);
      if (file.download_url) return file;
    } catch (error) {
      if (!String(error.message).includes('404')) throw error;
    }
    await sleep(config.POLL_INTERVAL_MS);
  }
  throw new Error('APK tidak ditemukan di branch output sebelum timeout.');
}

async function downloadBinary(url) {
  const res = await fetch(url, {
    headers: {
      Authorization: `Bearer ${config.GITHUB_TOKEN}`,
      'User-Agent': 'telegram-flutter-builder-bot'
    }
  });
  if (!res.ok) throw new Error(`Failed to download binary: ${res.status}`);
  const arrayBuffer = await res.arrayBuffer();
  return Buffer.from(arrayBuffer);
}

function getHelpText() {
  return [
    '*Flutter ZIP → APK Builder*',
    '',
    'Kirim file *.zip* project Flutter Anda.',
    'Bot akan:',
    '1. Upload ZIP ke GitHub repo Anda',
    '2. Menjalankan GitHub Actions build Flutter APK',
    '3. Mengambil hasil APK',
    '4. Mengirim APK kembali ke Telegram',
    '',
    'Perintah:',
    '/start - mulai',
    '/help - bantuan',
    '/status - cek apakah bot hidup'
  ].join('\n');
}

async function handleCommand(message) {
  const chatId = message.chat.id;
  const text = (message.text || '').trim();

  if (text === '/start' || text === '/help') {
    await sendMessage(chatId, getHelpText());
    return;
  }

  if (text === '/status') {
    await sendMessage(chatId, 'Bot aktif. Kirim file ZIP project Flutter untuk mulai build APK.');
    return;
  }

  await sendMessage(chatId, 'Perintah tidak dikenal. Gunakan /help');
}

async function handleDocument(message) {
  const chatId = message.chat.id;
  const doc = message.document;

  if (state.busyChats.has(chatId)) {
    await sendMessage(chatId, 'Masih ada proses build yang berjalan untuk chat ini. Tunggu sampai selesai dulu.');
    return;
  }

  const fileName = doc.file_name || 'project.zip';
  const lower = fileName.toLowerCase();
  const sizeMb = (doc.file_size || 0) / (1024 * 1024);

  if (!lower.endsWith('.zip')) {
    await sendMessage(chatId, 'File harus berformat .zip');
    return;
  }

  if (sizeMb > config.MAX_ZIP_MB) {
    await sendMessage(chatId, `Ukuran file terlalu besar. Maksimum ${config.MAX_ZIP_MB} MB.`);
    return;
  }

  state.busyChats.add(chatId);

  const buildId = randomId('build');
  const zipRepoPath = `incoming/${buildId}.zip`;

  try {
    await sendMessage(chatId, `ZIP diterima.\nBuild ID: \`${buildId}\`\nSedang upload ke GitHub...`);

    const zipBytes = await getTelegramFileBytes(doc.file_id);

    await ensureBranch(config.GITHUB_OUTPUT_BRANCH, config.GITHUB_BRANCH);
    await upsertRepoFile(
      zipRepoPath,
      zipBytes,
      `chore: upload source zip for ${buildId}`,
      config.GITHUB_BRANCH
    );

    await sendMessage(chatId, 'ZIP sudah diupload. Menjalankan workflow build APK di GitHub Actions...');
    await triggerBuild(buildId, zipRepoPath);

    const run = await waitForRun(buildId);

    if (run.conclusion !== 'success') {
      const runUrl = run.html_url || `https://github.com/${config.GITHUB_OWNER}/${config.GITHUB_REPO}/actions`;
      throw new Error(`Build gagal. Conclusion: ${run.conclusion}. Cek log: ${runUrl}`);
    }

    await sendMessage(chatId, 'Build selesai. Mengambil APK hasil build...');
    const apkMeta = await waitForApk(buildId);
    const apkBytes = await downloadBinary(apkMeta.download_url);

    await sendDocumentFromBuffer(chatId, apkBytes, `${buildId}.apk`, `Build berhasil: ${buildId}`);
    await sendMessage(chatId, `Selesai. APK juga tersimpan di branch \`${config.GITHUB_OUTPUT_BRANCH}\` pada path \`builds/${buildId}.apk\`.`);
  } catch (error) {
    console.error(error);
    await sendMessage(chatId, `Terjadi error saat build:\n\`${escapeMarkdown(String(error.message).slice(0, 3500))}\``);
  } finally {
    try {
      await deleteRepoFile(zipRepoPath, `chore: cleanup source zip for ${buildId}`, config.GITHUB_BRANCH);
    } catch (cleanupError) {
      console.error('Cleanup failed:', cleanupError);
    }
    state.busyChats.delete(chatId);
  }
}

function escapeMarkdown(text) {
  return text.replace(/([_\-*\[\]()~`>#+=|{}.!])/g, '\\$1');
}

async function processUpdate(update) {
  state.offset = update.update_id + 1;
  const message = update.message;
  if (!message || !message.chat) return;

  if (!isAllowedChat(message.chat.id)) {
    await sendMessage(message.chat.id, 'Chat ini tidak diizinkan menggunakan bot.');
    return;
  }

  if (message.text) {
    await handleCommand(message);
    return;
  }

  if (message.document) {
    await handleDocument(message);
    return;
  }

  await sendMessage(message.chat.id, 'Kirim file ZIP project Flutter atau gunakan /help');
}

async function pollLoop() {
  while (true) {
    try {
      const result = await tg('getUpdates', {
        offset: state.offset,
        timeout: 30,
        allowed_updates: ['message']
      });

      for (const update of result) {
        try {
          await processUpdate(update);
        } catch (error) {
          console.error('processUpdate failed:', error);
        }
      }
    } catch (error) {
      console.error('pollLoop error:', error);
      await sleep(3000);
    }
  }
}

function startHealthServer() {
  const server = http.createServer((req, res) => {
    if (req.url === '/health') {
      res.writeHead(200, { 'content-type': 'application/json' });
      res.end(JSON.stringify({ ok: true, service: 'telegram-flutter-builder-bot' }));
      return;
    }

    res.writeHead(200, { 'content-type': 'text/plain' });
    res.end('Bot is running');
  });

  server.listen(config.WEBHOOK_PORT, () => {
    console.log(`Health server listening on port ${config.WEBHOOK_PORT}`);
  });
}

(async () => {
  try {
    assertConfig();
    startHealthServer();
    console.log('Bot started with long polling...');
    await pollLoop();
  } catch (error) {
    console.error('Fatal:', error);
    process.exit(1);
  }
})();
