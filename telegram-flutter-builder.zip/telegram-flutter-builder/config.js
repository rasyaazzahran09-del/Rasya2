'use strict';

module.exports = {
  TELEGRAM_BOT_TOKEN: process.env.TELEGRAM_BOT_TOKEN || '8598777759:AAFcSksZiBygWF2N7YnpKPuUyoPDBaAxXFc',
  GITHUB_TOKEN: process.env.GITHUB_TOKEN || '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',
  GITHUB_OWNER: process.env.GITHUB_OWNER || 'rasyaazzahran09-del',
  GITHUB_REPO: process.env.GITHUB_REPO || 'Rasya2',
  GITHUB_BRANCH: process.env.GITHUB_BRANCH || 'main',
  GITHUB_WORKFLOW_ID: process.env.GITHUB_WORKFLOW_ID || 'build-flutter-apk.yml',
  GITHUB_OUTPUT_BRANCH: process.env.GITHUB_OUTPUT_BRANCH || 'apk-output',
  POLL_INTERVAL_MS: Number(process.env.POLL_INTERVAL_MS || 4000),
  BUILD_TIMEOUT_MS: Number(process.env.BUILD_TIMEOUT_MS || 1000 * 60 * 30),
  MAX_ZIP_MB: Number(process.env.MAX_ZIP_MB || 45),
  ALLOWED_CHAT_IDS: (process.env.ALLOWED_CHAT_IDS || '')
    .split(',')
    .map((v) => v.trim())
    .filter(Boolean),
  WEBHOOK_PORT: Number(process.env.PORT || 3000),
  APP_URL: process.env.APP_URL || '',
  SECRET_TOKEN: process.env.SECRET_TOKEN || ''
};
