# Telegram Flutter ZIP to APK Builder

Bot Telegram Node.js tanpa dependency eksternal. Cocok untuk panel yang menjalankan startup:

```bash
node index.js
```

## Cara kerja

- User kirim file ZIP project Flutter ke bot Telegram.
- Bot download ZIP dari Telegram.
- Bot upload ZIP ke repository GitHub Anda.
- Bot trigger GitHub Actions workflow.
- GitHub runner memasang Flutter + Java lalu build APK.
- APK hasil build disimpan ke branch output (`apk-output` secara default).
- Bot mengambil APK dan mengirimkannya kembali ke Telegram.

## Kenapa ini dipakai

Server panel **tidak perlu** Flutter SDK, Android SDK, emulator, atau device Android.
Semua proses build dilakukan di GitHub Actions.

## Environment Variables

- `TELEGRAM_BOT_TOKEN`
- `GITHUB_TOKEN` → pakai Personal Access Token dengan akses repo + actions
- `GITHUB_OWNER`
- `GITHUB_REPO`
- `GITHUB_BRANCH` (default: `main`)
- `GITHUB_WORKFLOW_ID` (default: `build-flutter-apk.yml`)
- `GITHUB_OUTPUT_BRANCH` (default: `apk-output`)
- `POLL_INTERVAL_MS` (default: `4000`)
- `BUILD_TIMEOUT_MS` (default: `1800000`)
- `MAX_ZIP_MB` (default: `45`)
- `ALLOWED_CHAT_IDS` (opsional, pisahkan koma)
- `PORT` (default: `3000`)

## Catatan penting

1. ZIP harus berisi project Flutter yang valid.
2. File `pubspec.yaml` harus ada di root project di dalam ZIP.
3. Jika project butuh Android signing custom, workflow perlu ditambah keystore.
4. Tanpa menjalankan dependency install di panel, bot ini tetap bisa hidup karena memakai fitur native Node 20+ (`fetch`, `FormData`, `Blob`).
5. Tetapi build APK Flutter **tetap membutuhkan** Flutter SDK dan Android toolchain di suatu tempat. Dalam solusi ini, tempatnya adalah GitHub Actions.

## Startup Panel

```bash
node index.js
```
